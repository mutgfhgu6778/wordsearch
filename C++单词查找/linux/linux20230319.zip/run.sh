gcc -o input_search main.c word.c line.c para.c
