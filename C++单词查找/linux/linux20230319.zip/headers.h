#if !defined(AFX_HEADERS_H__9CD8B6D4_B52C_4C25_982D_5AD52A431326__INCLUDED_)
#define AFX_HEADERS_H__9CD8B6D4_B52C_4C25_982D_5AD52A431326__INCLUDED_


#include "definitions.h"
#include "word.h"
#include "line.h"
#include "para.h"

#endif